/* File: Person.java
 * Author: Stanley Pieda, modified: George Kriger
 * Date: 2015
 * Modified: George Kriger, 2022
 * Description: example of Telescoping Constructors
 * Builder DP should be used instead.
 */
package personPkg;

public class Person {

    private int personID;
    private String firstName;
    private String lastName;
    private String phone;
    private String email;

    public int getpersonID(){ return personID; }
    public void setpersonID(int personID){this.personID = personID; }

    public String getFirstName(){ return firstName; }
    public void setLirstName(String firstName){this.firstName = firstName;}

    public String getLastName(){ return lastName; }
    public void setLastName(String lastName){this.lastName = lastName;}

    public String getPhone(){ return phone; }
    public void setPhone(String phone){this.phone = phone;}

    public String getEmail(){ return email; }
    public void setEmail(String email){this.email = email;}

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("[")
                .append(firstName).append(" ")
                .append(lastName).append(" ")
                .append(phone).append(" ")
                .append(email).append("]"); // .append(System.lineSeparator());
        return sb.toString();
    }

    /* These telescoping constructors are obsolete with the builder pattern
	 * Also when using long constructors the meaning of the parameters isn't always self evident.
	 * Also I can't overload a constructor for Person(personID, firstName, phone)
	 * because the parameters (int, String, String) were already used for
	 * (personID, firstName, lastName)
     */
    public Person(int personID, String firstName, String lastName, String phone, String email) {
        super();
        this.personID = personID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phone = phone;
        this.email = email;
    }

    public Person(int personID, String firstName, String lastName, String phone) {
        this(personID, firstName, lastName, phone, null);
    }

    public Person(int personID, String firstName, String lastName) {
        this(personID, firstName, lastName, null, null);
    }

    public Person(int personID, String firstName) {
        this(personID, firstName, null, null, null);
    }

    public Person(int personID) {
        this(personID, null, null, null, null);
    }

    public Person() {
        this(1, null, null, null, null);
    }
}//class
