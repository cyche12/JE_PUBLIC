package builderExample0_Test;

import personPkg.Person;

/**
 * class to show/test features of the Person class
 *
 * @author kriger
 */
public class PersonTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Person a = new Person(1, "First", "Last", "123 123 1234", "a@b.com");

        Person b = new Person(0, "Fname", "Lname", null, "ab@c.com");
        // class has no way to create a Person without a phone number
        // so must use the 5 parameter constructor

        System.out.println(a);
//         System.out.println(a.toString()); // same as the line above;;

        System.out.println(b);
//         System.out.println(b.toString()); // same as the line above
    }

}
