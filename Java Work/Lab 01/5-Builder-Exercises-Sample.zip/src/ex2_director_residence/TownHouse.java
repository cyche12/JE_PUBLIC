/* Author: Gustavo Adami
 * Date: September 2023
 * Description: Demonstration of builder design pattern
 */
package ex2_director_residence;

public class TownHouse implements IResidenceBuilder {

    private ConstructionDetails townHouseDetails = new ConstructionDetails();

    @Override
    public void buildWalls() {
        townHouseDetails.setWalls("Townhouse - Walls");
    }

    @Override
    public void buildDoors() {
        townHouseDetails.setDoors("Townhouse - Doors");
    }

    @Override
    public void buildWindows() {
        townHouseDetails.setWindows("Townhouse - Windows");
    }

    @Override
    public void buildRoof() {
        townHouseDetails.setRoof("Townhouse - Roof");
    }

    @Override
    public void buildGarage() {
        townHouseDetails.setGarage("Townhouse - Garage");
    }

    @Override
    public ConstructionDetails getConstructionDetails() {
        return townHouseDetails;
    }
}
