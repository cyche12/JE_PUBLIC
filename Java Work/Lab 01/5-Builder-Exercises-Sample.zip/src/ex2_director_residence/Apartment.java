/* Author: Gustavo Adami
 * Date: September 2023
 * Description: Demonstration of builder design pattern
 */
package ex2_director_residence;

public class Apartment implements IResidenceBuilder {

    //    private String walls;
    //    private String doors;
    //    private String windows;
    //    private String roof;
    //    private String garage;
    // Properties extracted and represented in another class/data structure
    private ConstructionDetails apartmentBuildingDetails = new ConstructionDetails();

    @Override
    public void buildWalls() {
        apartmentBuildingDetails.setWalls("Apartment - Walls");
    }

    @Override
    public void buildDoors() {
        apartmentBuildingDetails.setDoors("Apartment - Doors");
    }

    @Override
    public void buildWindows() {
        apartmentBuildingDetails.setWindows("Apartment - Windows");
    }

    @Override
    public void buildRoof() {
        apartmentBuildingDetails.setRoof("Apartment - Roof");
    }

    @Override
    public void buildGarage() {
        apartmentBuildingDetails.setGarage("Apartment - Garage");
    }

    @Override
    public ConstructionDetails getConstructionDetails() {
        return apartmentBuildingDetails;
    }
}
