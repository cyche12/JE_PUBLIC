/* Author: Gustavo Adami
 * Date: September 2023
 * Description: Demonstration of builder design pattern
 */
package ex2_director_residence;

public class RunResidenceBuilder {

    public static void main(String[] args) {
        Director director = new Director();
        IResidenceBuilder apartmentBuilder = new Apartment();
        IResidenceBuilder townHouseBuilder = new TownHouse();

        director.buildResidence(apartmentBuilder);
        director.buildResidence(townHouseBuilder);

        ConstructionDetails apartmentDetails = apartmentBuilder.getConstructionDetails();
        System.out.println("APARTMENT DETAILS\n" + apartmentDetails + "\n\n");

        ConstructionDetails townHouseDetails = townHouseBuilder.getConstructionDetails();
        System.out.println("TOWNHOUSE DETAILS\n" + townHouseDetails);
    }
}
