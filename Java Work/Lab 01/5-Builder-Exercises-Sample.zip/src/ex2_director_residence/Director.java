/* Author: Gustavo Adami
 * Date: September 2023
 * Description: Demonstration of builder design pattern
 */
package ex2_director_residence;

public class Director {

    public void buildResidence(IResidenceBuilder builder) {
        builder.buildWalls();
        builder.buildDoors();
        builder.buildWindows();
        builder.buildRoof();
        builder.buildGarage();
    }

// Able to "summarize" in one single method using the interface,
//  since steps are the same.
//    public void buildApartment(Apartment builder) {
//        builder.buildWalls()
//                .buildDoors()
//                .buildWindows()
//                .buildRoof()
//                .buildGarage();
//    }
//
//    public void buildCondo(Condo builder) {
//        builder.buildWalls()
//                .buildDoors()
//                .buildWindows()
//                .buildRoof()
//                .buildGarage();
//    }
//
//    public void buildTownHouse(TownHouse builder) {
//        builder.buildWalls()
//                .buildDoors()
//                .buildWindows()
//                .buildRoof()
//                .buildGarage();
//    }
}
