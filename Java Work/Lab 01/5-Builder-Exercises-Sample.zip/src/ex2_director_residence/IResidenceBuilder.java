/* Author: Gustavo Adami
 * Date: September 2023
 * Description: Demonstration of builder design pattern
 */
package ex2_director_residence;

public interface IResidenceBuilder {

    void buildWalls();

    void buildDoors();

    void buildWindows();

    void buildRoof();

    void buildGarage();

    ConstructionDetails getConstructionDetails();
}
