/* Author: Gustavo Adami
 * Date: September 2023
 * Description: Demonstration of builder design pattern
 */
package ex2_director_residence;

public class ConstructionDetails {

    private String walls;
    private String doors;
    private String windows;
    private String roof;
    private String garage;

    public String getWalls() {
        return walls;
    }

    public void setWalls(String walls) {
        this.walls = walls;
    }

    public String getDoors() {
        return doors;
    }

    public void setDoors(String doors) {
        this.doors = doors;
    }

    public String getWindows() {
        return windows;
    }

    public void setWindows(String windows) {
        this.windows = windows;
    }

    public String getRoof() {
        return roof;
    }

    public void setRoof(String roof) {
        this.roof = roof;
    }

    public String getGarage() {
        return garage;
    }

    public void setGarage(String garage) {
        this.garage = garage;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("[")
                .append(walls).append("\n")
                .append(doors).append("\n")
                .append(windows).append("\n")
                .append(roof).append("\n")
                .append(garage).append("]");
        return sb.toString();
    }
}
