/* Author: Gustavo Adami
 * Date: September 2023
 * Description: Demonstration of builder design pattern
 */
package ex1_simple_house;

public class House {

    private String walls;
    private String doors;
    private String windows;
    private String roof;
    private String garage;
    private String table;
    private String swimmingPool;

    public String getWalls() {
        return walls;
    }

    public void setWalls(String walls) {
        this.walls = walls;
    }

    public String getDoors() {
        return doors;
    }

    public void setDoors(String doors) {
        this.doors = doors;
    }

    public String getWindows() {
        return windows;
    }

    public void setWindows(String windows) {
        this.windows = windows;
    }

    public String getRoof() {
        return roof;
    }

    public void setRoof(String roof) {
        this.roof = roof;
    }

    public String getGarage() {
        return garage;
    }

    public void setGarage(String garage) {
        this.garage = garage;
    }

    public String getTable() {
        return table;
    }

    public void setTable(String table) {
        this.table = table;
    }

    public String getSwimmingPool() {
        return swimmingPool;
    }

    public void setSwimmingPool(String swimmingPool) {
        this.swimmingPool = swimmingPool;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("[")
                .append(walls).append(" ")
                .append(doors).append(" ")
                .append(windows).append(" ")
                .append(roof).append(" ")
                .append(table).append(" ")
                .append(garage).append(" ")
                .append(swimmingPool).append("]");
        return sb.toString();
    }

    public House(HouseBuilder houseBuilder) {
        walls = houseBuilder.getWalls();
        doors = houseBuilder.getDoors();
        windows = houseBuilder.getWindows();
        roof = houseBuilder.getRoof();
        garage = houseBuilder.getGarage();
        table = houseBuilder.getTable();
        swimmingPool = houseBuilder.getSwimmingPool();
    }
}
