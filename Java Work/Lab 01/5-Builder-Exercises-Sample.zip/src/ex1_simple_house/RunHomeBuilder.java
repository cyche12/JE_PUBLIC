/* Author: Gustavo Adami
 * Date: September 2023
 * Description: Demonstration of builder design pattern
 */
package ex1_simple_house;

public class RunHomeBuilder {

    public static void main(String[] args) {
        House house = HouseBuilder.create()
                .walls("Bulding Walls")
                .doors("Doors")
                .windows("Windows")
                .roof("Roof")
                .garage("Garage")
                .build();

        System.out.println(house);

        House anotherHouse = HouseBuilder.create()
                .table("add a table")
                .walls("build walls")
                //                .windows("build windows")
                //                .garage("build garage")
                .roof("add roof finally")
                .build();

        System.out.println(anotherHouse);

        House jacuzziHouse = HouseBuilder.create()
                .table("big table")
                .walls("walls")
                .swimmingPool("jacuzzi")
                .build();

        System.out.println(jacuzziHouse);
    }
}
