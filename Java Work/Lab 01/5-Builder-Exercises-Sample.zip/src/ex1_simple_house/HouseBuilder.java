/* Author: Gustavo Adami
 * Date: September 2023
 * Description: Demonstration of builder design pattern
 */
package ex1_simple_house;

public class HouseBuilder {

    private String walls;
    private String doors;
    private String windows;
    private String roof;
    private String garage;
    private String table;
    private String swimmingPool;

    public String getSwimmingPool() {
        return swimmingPool;
    }

    public String getWalls() {
        return walls;
    }

    public String getDoors() {
        return doors;
    }

    public String getWindows() {
        return windows;
    }

    public String getRoof() {
        return roof;
    }

    public String getGarage() {
        return garage;
    }

    public String getTable() {
        return table;
    }

    /*
     * Constructor was marked private to enforce use of create() method
     */
    private HouseBuilder() {
    }

    /*
     * Returns an instance of this PersonBuilder
     */
    public static HouseBuilder create() {
        return new HouseBuilder();
    }

    /*
     * Each method accepts the data, sets the data into a field,
     * then returns a reference to 'this' 
     * When used it means I can chain the method calls:
     */
    public HouseBuilder walls(String walls) {
        this.walls = walls;
        return this;
    }

    public HouseBuilder doors(String doors) {
        this.doors = doors;
        return this;
    }

    public HouseBuilder windows(String windows) {
        this.windows = windows;
        return this;
    }

    public HouseBuilder roof(String roof) {
        this.roof = roof;
        return this;
    }

    public HouseBuilder garage(String garage) {
        this.garage = garage;
        return this;
    }

    public HouseBuilder table(String table) {
        this.table = table;
        return this;
    }

    public HouseBuilder swimmingPool(String swimmingPool) {
        this.swimmingPool = swimmingPool;
        return this;
    }

    public House build() {
        return new House(this);
    }
}
