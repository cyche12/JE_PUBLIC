package cst8288.c_loggingsingleton;

/**
 * @author Gustavo Adami CST8288 2023-09
 */
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

public class Logger {

    private static Logger instance;
    private PrintWriter logFile;

    // Private constructor to prevent external instantiation
    private Logger() {
        try {
            logFile = new PrintWriter(new FileWriter("logger.log", true));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static Logger getInstance() {
        if (instance == null) {
            instance = new Logger();
        }
        return instance;
    }

    public void log(String message) {
        String timestamp = new Date().toString();
        logFile.println(timestamp + ": " + message);
        logFile.flush();
    }

    public void close() {
        if (logFile != null) {
            logFile.close();
        }
    }
}
