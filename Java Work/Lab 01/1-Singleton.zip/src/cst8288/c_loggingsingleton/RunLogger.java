package cst8288.c_loggingsingleton;

/**
 * @author Gustavo Adami CST8288 2023-09
 */
public class RunLogger {

    public static void main(String[] args) {
        Logger logger = Logger.getInstance();
        logger.log("This is my log");

        logger.close();
    }
}
