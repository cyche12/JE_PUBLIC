package cst8288.a_samplesingleton;

/**
 * @author Gustavo Adami CST8288 2023-09
 */
public class SingletonSample {

    /* private static variable that stores reference to single instance */
    private static SingletonSample singleObject;

    /* Private constructor, so no other class can call it and create other instances */
    private SingletonSample() {
    }

    /* Static method that returns reference to single instance.
     * Initializes it only once, if not initialized before */
    public static SingletonSample getInstance() {
        if (singleObject == null) {
            singleObject = new SingletonSample();
        }

        return singleObject;
    }

    /* Any methods that perform some kind of action */
    public void workerMethod() {
        System.out.println("Do what you were designed to do");
    }
}
