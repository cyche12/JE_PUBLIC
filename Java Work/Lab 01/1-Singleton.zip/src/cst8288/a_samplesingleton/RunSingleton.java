package cst8288.a_samplesingleton;

/**
 * @author Gustavo Adami CST8288 2023-09
 */
public class RunSingleton {

    public static void main(String[] args) {
        SingletonSample singleton = SingletonSample.getInstance();
        singleton.workerMethod();

        SingletonSample anotherObject = SingletonSample.getInstance();
        anotherObject.workerMethod();

        System.out.println("Are the two objects the same? -> " + (singleton == anotherObject));
    }
}
