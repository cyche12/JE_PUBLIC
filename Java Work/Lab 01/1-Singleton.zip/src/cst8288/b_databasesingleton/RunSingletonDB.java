package cst8288.b_databasesingleton;

/**
 * @author Gustavo Adami CST8288 2023-09
 */
public class RunSingletonDB {

    public static void main(String[] args) {
        Database database = Database.getInstance();
        database.getConnection();

        Database database2 = Database.getInstance();
        database.getConnection();

        System.out.println("Are the two objects the same? -> " + (database == database2));
    }
}
