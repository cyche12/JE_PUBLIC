package cst8288.b_databasesingleton;

/**
 * @author Gustavo Adami CST8288 2023-09
 */
public class Database {

    private static Database database;

    private Database() {
    }

    public static Database getInstance() {
        if (database == null) {
            database = new Database();
        }

        return database;
    }

    public void getConnection() {
        System.out.println("Successfully connected to the database");
    }

}
