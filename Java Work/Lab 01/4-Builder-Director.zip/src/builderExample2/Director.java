package builderExample2;

// "Director" 
class Director {

    IBuilder myBuilder;

    // A series of steps -for the production
    public void build(IBuilder builder) {
        myBuilder = builder;
        myBuilder.BuildBody();
        myBuilder.InsertWheels();
        myBuilder.AddHeadlights();
    }
}
