package builderExample2;
// modified from: Java Design Patterns by V.Sarcar

class BuilderPatternEx {

    public static void main(String[] args) {
        System.out.println("***Builder Pattern Demo***");

        Director director = new Director();

        IBuilder carBuilder = new Car();
        IBuilder motorBuilder = new MotorCycle();

        // Making Car
        director.build(carBuilder);
        Product p1 = carBuilder.GetVehicle();
        p1.Show();

        //Making MotorCycle
        director.build(motorBuilder);
        Product p2 = motorBuilder.GetVehicle();
        p2.Show();
    }
}
