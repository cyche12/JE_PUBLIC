package builderExample2;

// Builders common interface
interface IBuilder {

    void BuildBody();

    void InsertWheels();

    void AddHeadlights();

    Product GetVehicle();

}
