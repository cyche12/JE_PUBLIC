package g7_country_pkg;

import java.util.Set;
import static java.util.Set.copyOf;

/**
 * G7CountrySet functions as a product in the Simple Factory pattern
 *
 * @author kriger
 *
 */
public class G7CountrySet implements G7CountryCollection {

    /**
     * retrieve all G7 countries as a Set
     *
     * @return Set containing all G7 countries
     */
    public Set<String> getAllG7() {
        return copyOf(new G7CountryList().getAllG7());
    }

    /**
     * retrieve a Set of G7 countries by name
     *
     * @param name country name to search for among the G7 countries
     * @return Set of G7 countries which match the parameter. Can be an empty
     * List
     */
    public Set<String> getG7CountryByName(String name) {
        return copyOf(new G7CountryList().getG7CountryByName(name));
    }
}//class
