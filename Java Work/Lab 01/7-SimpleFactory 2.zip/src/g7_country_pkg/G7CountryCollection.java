package g7_country_pkg;

import java.util.Collection;

/**
 * interface for a Collection of G7 Countries. functions as product interface in
 * Simple Factory pattern
 *
 * @author kriger
 */
public interface G7CountryCollection {

    /**
     * method to obtain all G7 countries
     *
     * @return a Collection containing all G7 countries
     */
    Collection<String> getAllG7();

    /**
     * method to obtain the G7 country that matches the name provided
     *
     * @param name which G7 country is to be retrieved
     * @return a Collection containing the G7 country that matches the name
     * provided
     */
    Collection<String> getG7CountryByName(String name);
}
