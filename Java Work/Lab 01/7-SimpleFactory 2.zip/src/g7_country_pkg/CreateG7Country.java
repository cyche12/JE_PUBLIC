package g7_country_pkg;

/**
 * "product creator" class for Simple Factory pattern Simple Factory pattern
 * uses concrete class(es) for product creator without an interface or abstract
 * class. See "What about Simple Factory?" Kaptein P.572
 *
 * @author kriger
 */
public class CreateG7Country {

    /**
     * static method to obtain a Collection of G7 countries
     *
     * @param type collection type. Supports "LIST" and "SET". Otherwise throws
     * UnsupportedOperationException
     * @return a concrete instance of a product factory
     */
    public static G7CountryCollection getG7CountryCollection(String type) {
        switch (type) {
            case "LIST":
                return new G7CountryList();
            case "SET":
                return new G7CountrySet();
            default:
                throw (new UnsupportedOperationException());
        }
    }//method()
}//class
