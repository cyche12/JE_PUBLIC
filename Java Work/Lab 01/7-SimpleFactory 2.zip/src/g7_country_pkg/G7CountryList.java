package g7_country_pkg;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * G7CountryList functions as a product in the Simple Factory pattern
 *
 * @author kriger
 */
public class G7CountryList implements G7CountryCollection {

    private static final List<String> listG7
            = Arrays.asList("Canada", "France", "Germany", "Italy", "Japan", "USA", "UK");

    /**
     * retrieve all G7 countries as a List
     *
     * @return List containing all G7 countries
     */
    public List<String> getAllG7() {
        return listG7;
    }

    /**
     * retrieve List of G7 countries by name
     *
     * @param name country name to search for among the G7 countries
     * @return List of G7 countries which match the parameter. Can be an empty
     * List
     */
    public List<String> getG7CountryByName(String name) {
        List<String> tempList = new ArrayList();
        for (String s : listG7) {
            if (s.compareTo(name) == 0) {
                tempList.add(s);
            }
        }//for

        return tempList;

    }//getG7CountryByName()
}//class
