package simplefactoryexample;

import g7_country_pkg.CreateG7Country;

/**
 * Example program using Simple Factory pattern
 *
 * @author kriger
 */
public class SimpleFactoryExample {

    /**
     * main() method used as launcher
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Get all G7 countries as a List");
        System.out.println(CreateG7Country.getG7CountryCollection("LIST").getAllG7());

        System.out.println(); //spacer line

        System.out.println("Get all G7 countries as a Set");
        System.out.println(CreateG7Country.getG7CountryCollection("SET").getAllG7());

        System.out.println(); //spacer line

        System.out.println("Get \"Canada\" by name from G7CountryList");
        System.out.println(CreateG7Country.getG7CountryCollection("LIST").getG7CountryByName("Canada"));
    }

}
