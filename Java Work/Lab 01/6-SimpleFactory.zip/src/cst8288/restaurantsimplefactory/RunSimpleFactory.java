package cst8288.restaurantsimplefactory;

/**
 * @author Geekific Adapted 2024-01
 */
public class RunSimpleFactory {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Restaurant restaurant = new Restaurant();
        restaurant.orderBurger("BEEF");
        restaurant.orderBurger("VEGGIE");

    }

}
