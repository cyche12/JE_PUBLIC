package cst8288.restaurantsimplefactory;

/**
 * @author Geekific Adapted 2024-01
 */
public class VeggieBurger implements Burger {

    @Override
    public void prepare() {
        // Prepare Veggie Burger
        System.out.println("Preparing Veggie Burger...");
    }

}
