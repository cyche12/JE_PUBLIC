package cst8288.restaurantsimplefactory;

/**
 * @author Geekific Adapted 2024-01
 */
public class Restaurant {

    public Burger orderBurger(String request) {
        SimpleBurgerFactory factory = new SimpleBurgerFactory();
        Burger burger = factory.createBurger(request);
        burger.prepare();
        return burger;
    }

}
