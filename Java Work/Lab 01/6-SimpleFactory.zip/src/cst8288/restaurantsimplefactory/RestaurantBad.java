package cst8288.restaurantsimplefactory;

import cst8288.restaurantsimplefactory.BeefBurger;
import cst8288.restaurantsimplefactory.Burger;
import cst8288.restaurantsimplefactory.VeggieBurger;

/**
 * @author Geekific Adapted 2024-01
 */
public class RestaurantBad {

    public Burger orderBurger(String request) {
        Burger burger = null;
        if ("BEEF".equals(request)) {
            burger = new BeefBurger();
        } else if ("VEGGIE".equals(request)) {
            burger = new VeggieBurger();
        }

        return burger;
    }
}
