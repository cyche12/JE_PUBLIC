package cst8288.restaurantsimplefactory;

/**
 * @author Geekific Adapted 2024-01
 */
public interface Burger {

    void prepare();

}
