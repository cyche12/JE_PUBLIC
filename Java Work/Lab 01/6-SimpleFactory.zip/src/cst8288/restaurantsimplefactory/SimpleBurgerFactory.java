package cst8288.restaurantsimplefactory;

/**
 * @author Geekific Adapted 2024-01
 */
public class SimpleBurgerFactory {

    public Burger createBurger(String request) {
        Burger burger = null;
        if ("BEEF".equals(request)) {
            burger = new BeefBurger();
        } else if ("VEGGIE".equals(request)) {
            burger = new VeggieBurger();
        }

        return burger;
    }

}
