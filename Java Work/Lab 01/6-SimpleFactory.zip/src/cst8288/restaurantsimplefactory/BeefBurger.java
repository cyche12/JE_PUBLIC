package cst8288.restaurantsimplefactory;

/**
 * @author Geekific Adapted 2024-01
 */
public class BeefBurger implements Burger {

    @Override
    public void prepare() {
        // Prepare Beef Burger
        System.out.println("Preparing Beef Burger...");
    }

}
