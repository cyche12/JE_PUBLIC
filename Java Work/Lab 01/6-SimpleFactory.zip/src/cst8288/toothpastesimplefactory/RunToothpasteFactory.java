package cst8288.toothpastesimplefactory;

/**
 *
 * @author Gustavo Adami, GenerativeAI aided - CST8288 2024-01
 */
public class RunToothpasteFactory {

    public static void main(String[] args) {

        SimpleToothpasteFactory toothpasteFactory = new SimpleToothpasteFactory();

        Toothpaste mintToothpaste = toothpasteFactory.createToothpaste("mint");
        Toothpaste herbalToothpaste = toothpasteFactory.createToothpaste("herbal");
        Toothpaste whiteningToothpaste = toothpasteFactory.createToothpaste("whitening");

        mintToothpaste.brushTeeth();
        herbalToothpaste.brushTeeth();
        whiteningToothpaste.brushTeeth();
    }

}
