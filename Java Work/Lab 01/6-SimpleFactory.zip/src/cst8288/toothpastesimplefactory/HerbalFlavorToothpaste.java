package cst8288.toothpastesimplefactory;

/**
 *
 * @author Gustavo Adami, GenerativeAI aided - CST8288 2024-01
 */
public class HerbalFlavorToothpaste implements Toothpaste {

    @Override
    public void brushTeeth() {
        System.out.println("Brushing teeth with herbal-flavored toothpaste.");
    }

}
