package cst8288.toothpastesimplefactory;

/**
 *
 * @author Gustavo Adami, GenerativeAI aided - CST8288 2024-01
 */
// Simple Factory Class
public class SimpleToothpasteFactory {

    public static Toothpaste createToothpaste(String type) {
        switch (type.toLowerCase()) {
            case "mint":
                return new MintFlavorToothpaste();
            case "herbal":
                return new HerbalFlavorToothpaste();
            case "whitening":
                return new WhiteningToothpaste();
            default:
                throw new IllegalArgumentException("Invalid toothpaste type: " + type);
        }
    }

}
