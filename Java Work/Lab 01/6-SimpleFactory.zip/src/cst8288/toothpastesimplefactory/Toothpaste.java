package cst8288.toothpastesimplefactory;

/**
 *
 * @author Gustavo Adami, GenerativeAI aided - CST8288 2024-01
 */
// Product Interface
public interface Toothpaste {

    void brushTeeth();
}
