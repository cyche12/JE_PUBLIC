/* File: Person.java
 * Author: Stanley Pieda, modified: George Kriger
 * Date: 2015
 * Description: Demonstration of builder design pattern
 */
package builderExample1;

public class Person{
    
    private int personID;
    private String firstName;
    private String lastName;
    private String phone;
    private String email;

    public int getpersonID(){ return personID; }
    public void setpersonID(int personID){this.personID = personID; }

    public String getFirstName(){ return firstName; }
    public void setLirstName(String firstName){this.firstName = firstName;}

    public String getLastName(){ return lastName; }
    public void setLastName(String lastName){this.lastName = lastName;}

    public String getPhone(){ return phone; }
    public void setPhone(String phone){this.phone = phone;}

    public String getEmail(){ return email; }
    public void setEmail(String email){this.email = email;}

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("[")
        .append(firstName).append(" ")
        .append(lastName).append(" ")
        .append(phone).append(" ")
        .append(email).append("]"); // .append(System.lineSeparator());
        return sb.toString();
    }

    /*
     * This constructor accepts a PersonBuilder which is then used
     * to obtain the data for the fields.
     */
    public Person(PersonBuilder builder) {
        personID = builder.getpersonID();
        firstName = builder.getFirstName();
        lastName = builder.getLastName();
        phone = builder.getPhone();
        email = builder.getEmail();
    }
}//class
