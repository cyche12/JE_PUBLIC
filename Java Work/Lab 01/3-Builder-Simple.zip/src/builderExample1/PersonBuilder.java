/* File: PersonBuilder.java
Author: Stanley Pieda, modified: George Kriger
 * Date: 2015
 * Description: Demonstration of builder design pattern
 */
package builderExample1;

public class PersonBuilder{

    private int personID;
    private String firstName;
    private String lastName;
    private String phone;
    private String email;
    private String address;

    public int getpersonID(){ return personID; }
    public String getFirstName(){ return firstName; }
    public String getLastName(){ return lastName; }
    public String getPhone(){ return phone; }
    public String getEmail(){ return email; }
    public String getAddress() { return address; }

    /*
     * Constructor was marked private to enforce use of create() method
     */
    private PersonBuilder() { }

    /*
     * Returns an instance of this PersonBuilder
     */
    public static PersonBuilder create() { return new PersonBuilder(); }

    /*
     * Each method accepts the data, sets the data into a field,
     * then returns a reference to 'this' 
     * When used it means I can chain the method calls:
     * E.g. Person p = PersonBuilder.create().personID(1).firstName("First").lastName("Last")
     *                              .phone("123").email("a@b.c").build();
     */
    public PersonBuilder personID (int personID)     { this.personID = personID;   return this; }
    public PersonBuilder firstName(String firstName) { this.firstName = firstName; return this; }
    public PersonBuilder lastName (String lastName)  { this.lastName = lastName;   return this; }
    public PersonBuilder phone    (String phone)     { this.phone = phone;         return this; }
    public PersonBuilder email    (String email)     { this.email = email;         return this; }
    public PersonBuilder address  (String address)   { this.address = address;     return this; }

    //Uses the Person(PersonBuilder) constructor to create and initialize a Person
    public Person build() { return new Person(this); }

}

