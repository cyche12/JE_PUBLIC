/* File: PersonBuilderLauncher.java
 * Author: Stanley Pieda, modified: George Kriger
 * Date: 2015
 * Description: Demonstration of builder design pattern
 */
package builderExample1_Test;

import builderExample1.Person;
import builderExample1.PersonBuilder;

public class PersonBuilderLauncher {

    public static void main(String[] args) {
        Person a = PersonBuilder.create().personID(1).firstName("First")
                .lastName("Last").phone("123 123 1234").email("a@b.com")
                .build();

        Person b = PersonBuilder.create().lastName("LName")
                .email("ab@c.com").firstName("FName")
                .build();

        System.out.println(a);
        // System.out.println(a.toString()); // same as the line above

        System.out.println(b);
        // System.out.println(b.toString()); // same as the line above

    }
}
